#include <iostream>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
using namespace std;

pid_t pid = 0;

int main(){
	int sig;
	sigset_t set;
	signal(SIGUSR2, NULL);															// initialize the signal
	sigemptyset(&set);
	sigaddset(&set, SIGUSR1);
	sigprocmask(SIG_BLOCK, &set, NULL);												// set the signal to block, so the sigwait will only keep execute after getting the signal send from kill
	cout << "Parent execute first!" << endl;
	pid = fork();
	if(pid == 0){
		sigwait(&set, &sig);														// wait for signal to return
		cout << "\t1 " <<"This is child!" << " child pid: " << pid << " signal: " << sig << endl;
		exit(0);
	}
	else{
		sleep(3);
		cout << "\t1 "<< "This is parent!" << " parent pid: " << pid << endl;
		kill(pid, SIGUSR1);															// pass signal to child
	}

	sleep(10);

	cout << "Child execute first !" << endl;
	pid = fork();
	if(pid == 0){
		sleep(3);
		cout << "\t2 " << "This is child!" << " child pid: " << pid << endl;
		kill(pid, SIGUSR1);
	}
	else{
		sigwait(&set, &sig);
		cout << "\t2 "<<"This is parent!" << " parent pid: " << pid << " signal: " << sig << endl;
	}
	return 0;

}
