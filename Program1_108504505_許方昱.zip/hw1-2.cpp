
#include <iostream>
#include <iomanip>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
using namespace std;
# define MAX_LINE 1024
#define TRUE 1
int should_run = 1;
void redirect(char *fileName, int id){											// the function for redirect
	int fd;
	switch(id){
	case 0:																		// 0 : redirect from file
		fd = open(fileName, O_RDONLY);
		break;
	case 1:																		// 1 : redirect to file
		fd = open(fileName, O_WRONLY | O_TRUNC | O_CREAT, 0600);
		break;
	}
	dup2(fd,id);
	close(fd);
}

void exec(char *args[]){														// the function to run the command
	pid_t pid;
	pid = fork();

	if(pid == 0){
		execvp(args[0], args);
		exit(0);
	}
	else
		waitpid(pid, NULL, 0);													//wait for the child process to finish

	redirect("/dev/tty",0);														//stdIn redirect to the console and show on the screen
	redirect("/dev/tty",1);
}

void createPipe(char *args[]){													// the function for pipe command
	int fd[2];
	pipe(fd);
	dup2(fd[1], 1);																// point the stdOut to fd[1]
	close(fd[1]);
	exec(args);																	// run the command before the pipe command in order to get the output
	dup2(fd[0], 0);																// point the stdIn to fd[0]
	close(fd[0]);
}

void tokenize(char *input, char *tokenized, char *tokens[]){					//tokenize the input in order to get the right command after spliting
	int j= 0;
	char *pch;
	for(int i = 0; i< strlen(input); i++){
		if((input[i] != '>') && (input[i] != '<') && (input[i] != '|')){
			tokenized[j++] = input[i];
 		}
		else{																	// add space around redirect and pipe command
			tokenized[j++] = ' ';
			tokenized[j++] = input[i];
			tokenized[j++] = ' ';
		}
	}
	tokenized[--j] = '\0';

	int i = 0;
	pch = strtok(tokenized, " ");												// split input with space and store into tokens
	while(pch){
		tokens[i++] = pch;
		pch = strtok(NULL, " ");
	}
	tokens[i] = NULL;
}

int main() {

	char *args[MAX_LINE];
	char input[MAX_LINE];
	char tokenized[MAX_LINE * 2];
	char *tokens[MAX_LINE];
	char *fileNames[10];
	char **cmd;
	int flag = 0, i = 0, count = 0;

	while(TRUE){

		printf("shell$ ");
		fflush(stdout);															// clear the output buffer and move the buffered data to the console

		fflush(stdin);															// clear the stdIn register and ready to get new input
		fgets(input,MAX_LINE,stdin);											// get the command from user

		tokenize(input, tokenized, tokens);
		i = 0;
		cmd = tokens; 															// use a pointer to point to the first address of tokens
		while(*cmd != NULL){
			count = 0;
			if(strcmp(*cmd, "exit") == 0)										// if user input exit, then end the process
				exit(0);
			else if(strcmp(*cmd, "<") == 0){									// redirect from file command
				redirect(*(++cmd),0);
			}
			else if(strcmp(*cmd, ">") == 0){									// redirect to file command
				cmd++;
				if(*(cmd+1) != NULL && strcmp(*(cmd+1), ">") == 0){				// multiple redirect
					createPipe(args);											// change ">" to "| tee", so we will do pipe command first
					i = 0;
					args[i++] = "tee";											// and add tee command to the args( tee command will write the output to file and also write into pipe)
					args[i++] = *cmd;
					args[i] = NULL;
				}
				else{
					redirect(*cmd,1);											// the last redirect do need to use tee, we only need to write the output into file
				}
			}
			else if(strcmp(*cmd, "|") == 0){									// pipe command
				createPipe(args);
				i = 0;															// because we will run the command and get the output before the pipe command in the function, so we clear i to 0
			}
			else{																// no special command
				args[i++] = *cmd;												// store into args
				args[i] = NULL;													// and set the end of the command to Null
			}
			cmd++;																// pointer points to the next command
		}
		if(args[0] == NULL)														// if the user input enter, do nothing and keep going to get the next input
			continue;														    // if flag == 0, run the current command.
		exec(args);

	}
	return 0;

}

